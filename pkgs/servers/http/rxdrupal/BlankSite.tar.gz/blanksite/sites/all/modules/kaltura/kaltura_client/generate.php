<?php 

require_once("../../bootstrap.php");

$generator = new Php5ClientGenerator();
$generator->generate();